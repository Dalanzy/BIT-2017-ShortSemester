#ifndef MIN_C_H
#define MIN_C_H

#include <QMainWindow>
#include <QFileDialog>
#include <QWidget>
#include <QPushButton>
#include <QLabel>
#include <QHBoxLayout>
#include <QFile>
#include <QIODevice>
#include <QTextEdit>
#include <QVBoxLayout>
#include <QTextStream>
#include <QMessageBox>
#include <QDebug>
#include <lexAnalyzer.h>


class Min_C : public QWidget
{
    Q_OBJECT

public:
    explicit Min_C(QWidget *parent = 0);

    public slots:
        void slotOpenFileDialog();


private:
    QPushButton *openBtn;
    QPushButton *quitBtn;
    QTextEdit *showText;
};

#endif // MIN_C_H
