/*
File:	Core.cpp
Author:	Reskip
Team:	helloMaster

Program design practice in 2017 short semester
Micro program interpreter of new language Min-c

8/29
    Lexical analyzer Developed
*/
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstdio>
#include <algorithm>
#include <string>
#include <vector>
#include <cctype>
#include "lexAnalyzer.h"
#include "head.h"
#include "min_c.h"
#include "ui_min_c.h"

using namespace std;
string a;

//------打开文件对话框
void Min_C ::slotOpenFileDialog()
{
/*
getOpenFileName函数说明
函数原形： QStringList QFileDialog::getOpenFileNames(
QWidget * parent = 0,
const QString & caption = QString(),	//  打开文件对话框的标题
const QString & dir = QString(),			//	查找目录
const QString & filter = QString(),		//  设置需要过滤的文件格式
QString * selectedFilter = 0,
Options options = 0) [static]
*/
//---获取文件名
QString fileName = QFileDialog :: getOpenFileName(this, NULL, NULL, "*.h *.cpp *.txt");
QString temp;
string dat;

//---打开文件并读取文件内容
QFile file(fileName);

//--打开文件成功
if (file.open(QIODevice ::ReadOnly | QIODevice ::Text))
{
    QTextStream textStream(&file);
    string inputData="";
    while (!textStream.atEnd())
    {
        temp = textStream.readLine();
        dat = temp.toStdString();
        inputData += dat+"\n";
        //cout << dat << endl;
        //---QtextEdit按行显示文件内容
            }
    lexAn an = lexAn();
    auto tokenLst = an.analyze(inputData);
    for (auto i : tokenLst)
    {
        i.print();
        switch(i.type)
        {
        case TYPE_KEY:
        {
            showText->setTextColor(QColor("blue"));
            showText->insertPlainText(QString::fromStdString(i.val));
            break;
        }
        case TYPE_OPR:
        {
            showText->setTextColor(QColor("red"));
            showText->insertPlainText(QString::fromStdString(i.val));
            break;
        }
        default:
        {
            showText->setTextColor(QColor("black"));
            showText->insertPlainText(QString::fromStdString(i.val));
            break;
        }
        }
    }
}

else	//---打开文件失败
{
    /*
    information函数参数说明：
    函数原型
    QMessageBox::information(
    QWidget * parent,
    const QString & title,					//--- 标题
    const QString & text,					//---显示内容
    StandardButtons buttons = Ok,	//---OK按钮
    StandardButton defaultButton = NoButton)
    [static]
    */
    QMessageBox ::information(NULL, NULL, "open file error");
 }
}
