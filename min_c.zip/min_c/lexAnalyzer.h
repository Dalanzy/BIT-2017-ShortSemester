#pragma once
#ifndef __LEXAN__
#define __LEXAN__

#include <string>
#include <iostream>
#include <vector>
#include "head.h"

class token
{
public:
    int type;
    std::string val;
    token(int type, std::string val);
    void print();
    void trans();
};

class lexAn
{
public:
    lexAn();
    int getCharType(char x);
    int getTokenType(int status);
    std::vector<token> analyze(std::string inputData);
};
#endif // !__LEXAN__
