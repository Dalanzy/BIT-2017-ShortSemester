#include "min_c.h"
#include "ui_min_c.h"
#include "lexAnalyzer.h"
#include "head.h"
#include <iostream>

Min_C::Min_C(QWidget *parent) :
    QWidget(parent)

{
    //---按钮与label
    openBtn = new QPushButton("OPEN FILE", this);
    QFont font1("Microsoft YaHei");
    openBtn->setFont(font1);
    connect(openBtn, SIGNAL(clicked()), this, SLOT(slotOpenFileDialog()));
    quitBtn = new QPushButton("QUIT", this);
    quitBtn->setFont(font1);
    connect(quitBtn, SIGNAL(clicked()), this, SLOT(close()));

    //----showText
    showText = new QTextEdit();
    QFont font2("Microsoft YaHei", 10, 50);
    showText->setFont(font2);

    //---按钮与label布局
    QVBoxLayout *vLayout = new QVBoxLayout();
    vLayout->addStretch();
    vLayout->addWidget(openBtn);
    vLayout->addWidget(quitBtn);
    vLayout->addStretch();
    vLayout->setSpacing(10);
    //	hLayout->setContentsMargins(10, 2, 10, 2);

    //---3个控件整体布局
    QHBoxLayout *hLayout = new QHBoxLayout(this);
    hLayout->addLayout(vLayout);
    hLayout->addWidget(showText);
    hLayout->setSpacing(10);
    hLayout->setContentsMargins(10, 2, 10, 2);

    //--显示布局
    setLayout(hLayout);

    //---窗口属性
    resize(400, 300);
    setWindowTitle("min-C解释器");
}
