#pragma once
#include <string>
#include <iostream>
#include <vector>
#include <string>
#include <iostream>
#include <vector>
#include "head.h"

using namespace std;

class token
{
public:
    int type;
    string val;
    int line;
    token(int type, string val, int line);
    void print();
    void trans();
};

class lexAn
{
public:
    lexAn();
    int getCharType(char x);
    int getTokenType(int status);
    vector<token> analyze(string inputData);
};
