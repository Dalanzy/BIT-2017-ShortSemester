#ifndef TYPEDEF_H
#define TYPEDEF_H

typedef enum{
    BROWSE,
    EDIT,
}editorMode;

#endif // TYPEDEF_H

