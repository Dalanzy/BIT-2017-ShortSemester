#include "colormode.h"
#include <QApplication>

int colorMode = NIGHT;
