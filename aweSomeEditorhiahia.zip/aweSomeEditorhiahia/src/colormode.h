#ifndef COLORMODE_H
#define COLORMODE_H

#define DAY 0
#define NIGHT 1

extern int colorMode;

#endif // COLORMODE_H
