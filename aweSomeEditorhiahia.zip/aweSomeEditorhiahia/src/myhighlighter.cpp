#include "myhighlighter.h"

using namespace std;


MyHighLighter::MyHighLighter(QTextDocument *parent)
    : QSyntaxHighlighter(parent)
{
    QColor tempColor;
    tempColor.setNamedColor("#458B00");
    TYPE_KEY_FORMAT.setForeground(tempColor);
    //TYPE_KEY_FORMAT.setFontWeight(QFont::Bold);

    //TYPE_VAR_FORMAT.setFontItalic(true);

    //tempColor.setNamedColor("#CD2626");
    //TYPE_CON_FORMAT.setForeground(tempColor);

    tempColor.setNamedColor("#FFA500");
    TYPE_OPR_FORMAT.setForeground(tempColor);

    tempColor.setNamedColor("#A2CD5A");
    TYPE_DEL_FORMAT.setForeground(tempColor);

    //TYPE_FMT_FORMAT;
    TYPE_ERR_FORMAT.setForeground(Qt::red);

}

void MyHighLighter::highlightBlock(const QString &text)
{
    string dat = text.toStdString() + " ";
    //connect();
    lexAn an = lexAn();
    auto tokenLst = an.analyze(dat);
    int index = 0;
    int length = 0;
    //setFormat(index,3,TYPE_CON_FORMAT);
    for (auto i : tokenLst)
    {
        length = i.val.length();

        switch(i.type)
        {
            case TYPE_KEY: setFormat(index, length, TYPE_KEY_FORMAT); break;
            case TYPE_DEL: setFormat(index, length, TYPE_DEL_FORMAT); break;
            case TYPE_ERR: setFormat(index, length, TYPE_ERR_FORMAT); break;
            case TYPE_FMT: setFormat(index, length, TYPE_FMT_FORMAT); break;
            case TYPE_CON: setFormat(index, length, TYPE_CON_FORMAT); break;
            case TYPE_OPR: setFormat(index, length, TYPE_OPR_FORMAT); break;
            case TYPE_VAR: setFormat(index, length, TYPE_VAR_FORMAT); break;
            default: break;

        }
        index += length;
    }
}
