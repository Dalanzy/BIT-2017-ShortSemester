#include "myhighlighter.h"

using namespace std;


MyHighLighter::MyHighLighter(QTextDocument *parent)
    : QSyntaxHighlighter(parent)
{
    QColor tempColor;

    if (colorMode == NIGHT)
    {
        tempColor.setNamedColor(NIGHT_TYPE_KEY);
        TYPE_KEY_FORMAT.setForeground(tempColor);
        TYPE_KEY_FORMAT.setFontWeight(QFont::Bold);

        tempColor.setNamedColor(NIGHT_TYPE_VAR);
        TYPE_VAR_FORMAT.setForeground(tempColor);

        tempColor.setNamedColor(NIGHT_TYPE_CON);
        TYPE_CON_FORMAT.setForeground(tempColor);

        tempColor.setNamedColor(NIGHT_TYPE_OPR);
        TYPE_OPR_FORMAT.setForeground(tempColor);

        tempColor.setNamedColor(NIGHT_TYPE_DEL);
        TYPE_DEL_FORMAT.setForeground(tempColor);

        tempColor.setNamedColor(NIGHT_TYPE_FMT);
        TYPE_FMT_FORMAT.setForeground(tempColor);

        tempColor.setNamedColor(NIGHT_TYPE_ERR);
        TYPE_ERR_FORMAT.setForeground(tempColor);

        tempColor.setNamedColor(NIGHT_TYPE_NOTE);
        TYPE_NOTE_FORMAT.setForeground(tempColor);

        tempColor.setNamedColor(NIGHT_TYPE_QUO);
        TYPE_QUO_FORMAT.setForeground(tempColor);
    }
    else
    {
        tempColor.setNamedColor(DAY_TYPE_KEY);
        TYPE_KEY_FORMAT.setForeground(tempColor);
        TYPE_KEY_FORMAT.setFontWeight(QFont::Bold);

        tempColor.setNamedColor(DAY_TYPE_VAR);
        TYPE_VAR_FORMAT.setForeground(tempColor);

        tempColor.setNamedColor(DAY_TYPE_CON);
        TYPE_CON_FORMAT.setForeground(tempColor);

        tempColor.setNamedColor(DAY_TYPE_OPR);
        TYPE_OPR_FORMAT.setForeground(tempColor);

        tempColor.setNamedColor(DAY_TYPE_DEL);
        TYPE_DEL_FORMAT.setForeground(tempColor);

        tempColor.setNamedColor(DAY_TYPE_FMT);
        TYPE_FMT_FORMAT.setForeground(tempColor);

        tempColor.setNamedColor(DAY_TYPE_ERR);
        TYPE_ERR_FORMAT.setForeground(tempColor);

        tempColor.setNamedColor(DAY_TYPE_NOTE);
        TYPE_NOTE_FORMAT.setForeground(tempColor);

        tempColor.setNamedColor(DAY_TYPE_QUO);
        TYPE_QUO_FORMAT.setForeground(tempColor);
    }

}

void MyHighLighter::highlightBlock(const QString &text)
{
    string dat = text.toStdString() + "\n";
    lexAn an = lexAn();
    auto tokenLst = an.analyze(dat);
    int index = 0;
    int length = 0;
    //setFormat(index,3,TYPE_CON_FORMAT);
    for (auto i : tokenLst)
    {
        //cout << i.type;
        cout << i.val;
        length = i.val.length();

        switch(i.type)
        {
            case TYPE_KEY: setFormat(index, length, TYPE_KEY_FORMAT); break;
            case TYPE_DEL: setFormat(index, length, TYPE_DEL_FORMAT); break;
            case TYPE_ERR: setFormat(index, length, TYPE_ERR_FORMAT); break;
            case TYPE_FMT: setFormat(index, length, TYPE_FMT_FORMAT); break;
            case TYPE_CON: setFormat(index, length, TYPE_CON_FORMAT); break;
            case TYPE_OPR: setFormat(index, length, TYPE_OPR_FORMAT); break;
            case TYPE_VAR: setFormat(index, length, TYPE_VAR_FORMAT); break;
            case TYPE_NOTE: setFormat(index, length, TYPE_NOTE_FORMAT); break;
            case TYPE_QUO: setFormat(index, length, TYPE_QUO_FORMAT); break;
            default: setFormat(index, length, TYPE_VAR_FORMAT); break;
        }
        index += length;
    }
}
