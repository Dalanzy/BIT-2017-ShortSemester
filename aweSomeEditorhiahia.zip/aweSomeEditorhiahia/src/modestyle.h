#ifndef MODESTYLE_H
#define MODESTYLE_H

#define BTNSTYLE_NIGHT "QPushButton{background-color:rgb(40,40,40); font-family: Microsoft YaHei;\
                                    color:rgb(210,210,210);border:2px groove gray;border-radius:10px;padding:2px 4px;}"\
                       "QPushButton:hover{background-color:rgb(255,250,250); color:rgb(110,110,110);}"\
                       "QPushButton:pressed{background-color:rgb(255, 250, 250); color:rgb(110,110,110); border-style: inset;}"\
                       "QPushButton::menu-indicator:close{subcontrol-position: right center;\
                                                          subcontrol-origin: padding;\
                                                          image:url(:/new/prefix1/images/right_arrow_night.png);}"\
                       "QPushButton::menu-indicator:hover{subcontrol-position: right center;\
                                                          subcontrol-origin: padding;\
                                                          image:url(:/new/prefix1/images/right_arrow_night2.png);}"\
                       "QPushButton::menu-indicator:pressed{subcontrol-position: right center;\
                                                            subcontrol-origin: padding;\
                                                            image:url(:/new/prefix1/images/down_arrow.png);}"

#define BTNSTYLE_DAY "QPushButton{background-color:rgb(255,255,255); font-family: Microsoft YaHei;\
                                  color:rgb(110,110,110);border:2px groove grey;border-radius:10px;padding:2px 4px;}"\
                     "QPushButton:hover{background-color:rgb(250,250,250); color:rgb(110,110,110);}"\
                     "QPushButton:pressed{border-style: inset;}"\
                     "QPushButton::menu-indicator:close{subcontrol-position: right center;\
                                                        subcontrol-origin: padding;\
                                                        image:url(:/new/prefix1/images/right_arrow_night2.png);}"\
                     "QPushButton::menu-indicator:hover{subcontrol-position: right center;\
                                                        subcontrol-origin: padding;\
                                                        image:url(:/new/prefix1/images/right_arrow_night2.png);}"\
                     "QPushButton::menu-indicator:pressed{subcontrol-position: right center;\
                                                          subcontrol-origin: padding;\
                                                          image:url(:/new/prefix1/images/down_arrow.png);}"

#define WINDOW_NIGHT "background-color:rgb(25,25,25);"

#define WINDOW_DAY "background-color:rgb(255,255,255);"

#define EDITOR_NIGHT "background-color:rgb(30,30,30);border: 0.8px solid rgb(190,190,190);"

#define EDITOR_DAY "background-color:rgb(255,255,255);border: 0.8px solid rgb(100,100,100);"

#define MENU_NIGHT "QMenu{background-color:rgb(40,40,40); color: rgb(210,210,210); font-family: Microsoft YaHei;\
                          border:2px groove gray;border-radius:5px;padding:2px 4px;}"\
                   "QMenu::item:selected{background-color:rgb(255,250,250); color:rgb(110,110,110);}"\


#define MENU_DAY "QMenu{background-color:rgb(255,255,255); color: rgb(110,110,110); font-family: Microsoft YaHei;\
                        border:2px groove gray;border-radius:5px;padding:2px 4px;}"\
                 "QMenu::item:selected{background-color:rgb(250,250,250); color:rgb(110,110,110);}"

extern int colorMode;

#endif // MODESTYLE_H
