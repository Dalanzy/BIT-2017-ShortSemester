#ifndef MYHIGHLIGHTER_H
#define MYHIGHLIGHTER_H
#include <QSyntaxHighlighter>
#include <QTextCharFormat>
#include <QTextDocument>
#include <string>
#include <QDebug>
#include "lexAnalyzer.h"
#include "head.h"
#include "typedef.h"
#include "colormode.h"

#define NIGHT_TYPE_KEY "#9AC0CD"
#define NIGHT_TYPE_VAR "#FFFFFF"
#define NIGHT_TYPE_CON "#9EC544"
#define NIGHT_TYPE_OPR "#EE9A00"
#define NIGHT_TYPE_DEL "#D9D9DA"
#define NIGHT_TYPE_FMT "#FFFFFF"
#define NIGHT_TYPE_ERR "#EE2C2C"
#define NIGHT_TYPE_NOTE "#BA55D3"
#define NIGHT_TYPE_QUO "#9EC544"

#define DAY_TYPE_KEY "#458B00"
#define DAY_TYPE_VAR "#000000"
#define DAY_TYPE_CON "#00688B"
#define DAY_TYPE_OPR "#CD6600"
#define DAY_TYPE_DEL "#000000"
#define DAY_TYPE_FMT "#000000"
#define DAY_TYPE_ERR "#EE2C2C"
#define DAY_TYPE_NOTE "#7A378B"
#define DAY_TYPE_QUO "#228B22"

class MyHighLighter : public QSyntaxHighlighter
{
    Q_OBJECT

public:
    MyHighLighter(QTextDocument *parent = 0);

    QTextCharFormat TYPE_KEY_FORMAT;
    QTextCharFormat TYPE_VAR_FORMAT;
    QTextCharFormat TYPE_CON_FORMAT;
    QTextCharFormat TYPE_OPR_FORMAT;
    QTextCharFormat TYPE_DEL_FORMAT;
    QTextCharFormat TYPE_FMT_FORMAT;
    QTextCharFormat TYPE_ERR_FORMAT;
    QTextCharFormat TYPE_NOTE_FORMAT;
    QTextCharFormat TYPE_QUO_FORMAT;

protected:
    void highlightBlock(const QString &text) Q_DECL_OVERRIDE;

};
#endif // MYHIGHLIGHTER_H
