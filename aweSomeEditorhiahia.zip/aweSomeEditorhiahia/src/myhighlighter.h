#ifndef MYHIGHLIGHTER_H
#define MYHIGHLIGHTER_H
#include <QSyntaxHighlighter>
#include <QTextCharFormat>
#include <QTextDocument>
#include <string>
#include "lexAnalyzer.h"
#include "head.h"

class MyHighLighter : public QSyntaxHighlighter
{
    Q_OBJECT

public:
    MyHighLighter(QTextDocument *parent = 0);

    QTextCharFormat TYPE_KEY_FORMAT;
    QTextCharFormat TYPE_VAR_FORMAT;
    QTextCharFormat TYPE_CON_FORMAT;
    QTextCharFormat TYPE_OPR_FORMAT;
    QTextCharFormat TYPE_DEL_FORMAT;
    QTextCharFormat TYPE_FMT_FORMAT;
    QTextCharFormat TYPE_ERR_FORMAT;

protected:
    void highlightBlock(const QString &text) Q_DECL_OVERRIDE;

};
#endif // MYHIGHLIGHTER_H
