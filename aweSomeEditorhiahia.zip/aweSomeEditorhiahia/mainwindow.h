#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFileDialog>
#include <QWidget>
#include <QPushButton>
#include <QMenu>
#include <QAction>
#include <QHBoxLayout>
#include <QFile>
#include <QIODevice>
#include <QVBoxLayout>
#include <QTextStream>
#include <QMessageBox>
//#include <QDebug>
#include "ui_mainwindow.h"
#include "src/codeeditor.h"
#include "src/myhighlighter.h"
#include "src/modestyle.h"


class MainWindow : public QMainWindow,Ui::MainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    public slots:
        void slotOpenFileDialog();
        void setColorMode();

private:
     CodeEditor *configEditor;
     QPushButton *file, *execute, *setting, *help;
     QMenu *m_file, *m_execute, *m_setting, *m_help;
     QAction *m_openFile, *m_save, *m_saveAs, *m_run, *m_debug, *m_daymode, *m_nightmode,
             *m_aboutmin_C, *m_aboutUs;
};

#endif // MAINWINDOW_H
