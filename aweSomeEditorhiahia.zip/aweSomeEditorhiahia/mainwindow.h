#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QFileDialog>
#include <QWidget>
#include <QPushButton>
#include <QHBoxLayout>
#include <QFile>
#include <QIODevice>
#include <QVBoxLayout>
#include <QTextStream>
#include <QMessageBox>
#include <QDebug>
#include "ui_mainwindow.h"
#include "src/codeeditor.h"
#include "src/myhighlighter.h"
#include "src/typedef.h"
class MainWindow : public QMainWindow,Ui::MainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    public slots:
        void slotOpenFileDialog();

private:
     CodeEditor *configEditor;
     QPushButton *open, *debug;
};

#endif // MAINWINDOW_H
