#include "mainwindow.h"
#include <QFont>

//using namespace std;


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent)
{
    //---窗口属性
    this->setupUi(this);
    this->setFixedSize(600, 400);
    this->setWindowIcon(QIcon(":/new/prefix1/images/min_c.ico"));
    this->setWindowTitle("min-C解释器");
    this->setWindowFlags(Qt::WindowCloseButtonHint);

    //code编辑器
    configEditor = new CodeEditor(this);
    QFont font("Microsoft YaHei");
    configEditor->setFont(font);
    configEditor->setMode(EDIT);

    if (colorMode == NIGHT)
    {
        this->setStyleSheet(WINDOW_NIGHT);
        configEditor->setStyleSheet(EDITOR_NIGHT);
    }

    //文件按钮
    file = new QPushButton("File", this);
    //QFont font1("Microsoft YaHei");
    file->setStyleSheet(BTNSTYLE_NIGHT);
    //file->setFont(font1);

    m_file = new QMenu(this); //文件按钮的下拉菜单
    m_openFile = new QAction("Open", this);
    m_save = new QAction("Save", this);
    m_saveAs = new QAction("Save As", this);

    m_file->addAction(m_openFile);
    m_file->addAction(m_save);
    m_file->addAction(m_saveAs);
    file->setMenu(m_file);

    connect(m_openFile, SIGNAL(triggered()), this, SLOT(slotOpenFileDialog()));

    //执行按钮
    execute = new QPushButton("Execute", this);
    //execute->setFont(font1);
    execute->setStyleSheet(BTNSTYLE_NIGHT);

    m_execute = new QMenu(this); //调试的下拉菜单
    m_run = new QAction("Run", this);
    m_debug = new QAction("Debug", this);

    m_execute->addAction(m_run);
    m_execute->addAction(m_debug);
    execute->setMenu(m_execute);

    //切换配色
    setting = new QPushButton("Setting", this);
    //setting->setFont(font1);
    setting->setStyleSheet(BTNSTYLE_NIGHT);

    m_setting = new QMenu(this);
    m_daymode = new QAction("Day Mode", this);
    m_nightmode = new QAction("Night Mode", this);
    m_setting->addAction(m_daymode);
    m_setting->addAction(m_nightmode);
    setting->setMenu(m_setting);
    connect(m_daymode, SIGNAL(triggered()), this, SLOT(setColorMode()));
    connect(m_nightmode, SIGNAL(triggered()), this, SLOT(setColorMode()));

    //关闭按钮
    help = new QPushButton("Help", this);
    //help->setFont(font1);
    help->setStyleSheet(BTNSTYLE_NIGHT);
    m_help = new QMenu(this);
    m_aboutmin_C = new QAction("About min_C", this);
    m_aboutUs = new QAction("About Us", this);
    m_help->addAction(m_aboutmin_C);
    m_help->addAction(m_aboutUs);
    help->setMenu(m_help);

    //菜单样式
    m_file->setStyleSheet(MENU_NIGHT);
    m_execute->setStyleSheet(MENU_NIGHT);
    m_setting->setStyleSheet(MENU_NIGHT);
    m_help->setStyleSheet(MENU_NIGHT);

    //3个Button和1个CodeEditor的布局
    //gridLayout->setSpacing(60);
    gridLayout->addWidget(file,0,0);
    gridLayout->addWidget(execute,0,1);
    gridLayout->addWidget(setting,0,2);
    gridLayout->addWidget(help,0,3);
    gridLayout->setSpacing(10);
    gridLayout->addWidget(configEditor,1,0,1,8);
    MyHighLighter *highlighter = new MyHighLighter(configEditor->document());
}

void MainWindow ::setColorMode(){
        if (colorMode == DAY)
        {
            this->setStyleSheet(WINDOW_NIGHT);
            configEditor->setStyleSheet(WINDOW_NIGHT);//整体颜色
            colorMode = NIGHT;
            configEditor->highlightCurrentLine();//行亮颜色
            MyHighLighter *highlighter = new MyHighLighter(configEditor->document());//编辑框内容颜色

            file->setStyleSheet(BTNSTYLE_NIGHT);
            execute->setStyleSheet(BTNSTYLE_NIGHT);
            help->setStyleSheet(BTNSTYLE_NIGHT);
            setting->setStyleSheet(BTNSTYLE_NIGHT);

            m_file->setStyleSheet(MENU_NIGHT);
            m_execute->setStyleSheet(MENU_NIGHT);
            m_setting->setStyleSheet(MENU_NIGHT);
            m_help->setStyleSheet(MENU_NIGHT);
        }

        else
        {
            this->setStyleSheet(WINDOW_DAY);
            configEditor->setStyleSheet(WINDOW_DAY);
            colorMode = DAY;
            configEditor->highlightCurrentLine();
            MyHighLighter *highlighter = new MyHighLighter(configEditor->document());

            file->setStyleSheet(BTNSTYLE_DAY);
            execute->setStyleSheet(BTNSTYLE_DAY);
            help->setStyleSheet(BTNSTYLE_DAY);
            setting->setStyleSheet(BTNSTYLE_DAY);

            m_file->setStyleSheet(MENU_DAY);
            m_execute->setStyleSheet(MENU_DAY);
            m_setting->setStyleSheet(MENU_DAY);
            m_help->setStyleSheet(MENU_DAY);
        }
}

MainWindow::~MainWindow()
{
}
