#include "mainwindow.h"
#include <QFont>

//using namespace std;


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent)
{
    //---窗口属性
    this->setupUi(this);
    this->setFixedSize(400, 300);
    this->setWindowIcon(QIcon("min_c.ico"));
    this->setWindowTitle("min-C解释器");
    this->setWindowFlags(Qt::WindowCloseButtonHint);

    //code编辑器
    configEditor = new CodeEditor(this);
    QFont font("Microsoft YaHei");
    configEditor->setFont(font);
    configEditor->setMode(EDIT);

    if (colorMode == NIGHT)
    {
        this->setStyleSheet("background-color:rgb(25,25,25);");
        configEditor->setStyleSheet("background-color:rgb(30,30,30);\
                                     border: 0.8px solid rgb(190,190,190);");
    }


    //按钮样式
    QString btnstyle = "QPushButton{background-color:rgb(40,40,40);\
                      color:rgb(210,210,210);border:2px groove gray;border-radius:10px;padding:2px 4px;}"
                      "QPushButton:hover{background-color:rgb(255,250,250); color:rgb(100,100,100);}"
                      "QPushButton:pressed{background-color:rgb(255, 255, 240);border-style: inset;}";

    //打开文件按钮
    file = new QPushButton("FILE", this);
    QFont font1("Microsoft YaHei");
    file->setStyleSheet(btnstyle);
    file->setFont(font1);
    connect(file, SIGNAL(clicked()), this, SLOT(slotOpenFileDialog()));

    //调试按钮
    debug = new QPushButton("DEBUG", this);
    debug->setFont(font1);
    debug->setStyleSheet(btnstyle);

    //关闭按钮
    quit = new QPushButton("QUIT", this);
    quit->setFont(font1);
    quit->setStyleSheet(btnstyle);
    connect(quit, SIGNAL(clicked()), this, SLOT(close()));

    //切换配色
    change_mode = new QPushButton("CHANGE MODE", this);
    change_mode->setFont(font1);
    change_mode->setStyleSheet(btnstyle);
    connect(change_mode, SIGNAL(clicked()), this, SLOT(setColorMode()));

    //3个Button和1个CodeEditor的布局
    //gridLayout->setSpacing(60);
    gridLayout->addWidget(file,0,0);
    gridLayout->addWidget(debug,0,1);
    gridLayout->addWidget(quit,0,2);
    gridLayout->addWidget(change_mode,0,3);
    gridLayout->setSpacing(10);
    gridLayout->addWidget(configEditor,1,0,1,4);
    MyHighLighter *highlighter = new MyHighLighter(configEditor->document());
}

void MainWindow ::setColorMode(){
        if (colorMode == DAY)
        {
            this->setStyleSheet("background-color:rgb(25,25,25);");
            configEditor->setStyleSheet("background-color:rgb(30,30,30);\
                                         border: 0.8px solid rgb(190,190,190);");//整体颜色
            colorMode = NIGHT;
            configEditor->highlightCurrentLine();//行亮颜色
            MyHighLighter *highlighter = new MyHighLighter(configEditor->document());//编辑框内容颜色

            QString night_btnstyle = "QPushButton{background-color:rgb(40,40,40);\
                              color:rgb(210,210,210);border:2px groove gray;border-radius:10px;padding:2px 4px;}"
                              "QPushButton:hover{background-color:rgb(255,250,250); color:rgb(100,100,100);}"
                              "QPushButton:pressed{background-color:rgb(255, 255, 240);border-style: inset;}";
            file->setStyleSheet(night_btnstyle);
            debug->setStyleSheet(night_btnstyle);
            quit->setStyleSheet(night_btnstyle);
            change_mode->setStyleSheet(night_btnstyle);
        }

        else
        {
            this->setStyleSheet("background-color:rgb(255,255,255);");
            configEditor->setStyleSheet("background-color:rgb(255,255,255);\
                                         border: 0.8px solid rgb(100,100,100);");
            colorMode = DAY;
            configEditor->highlightCurrentLine();
            MyHighLighter *highlighter = new MyHighLighter(configEditor->document());

            QString night_btnstyle = "QPushButton{background-color:rgb(255,255,255);\
                              color:rgb(100,100,100);border:2px groove lightgrey;border-radius:10px;padding:2px 4px;}"
                              "QPushButton:hover{background-color:rgb(250,250,250); color:rgb(70,90,90);}"
                              "QPushButton:pressed{border-style: inset;}";
            file->setStyleSheet(night_btnstyle);
            debug->setStyleSheet(night_btnstyle);
            quit->setStyleSheet(night_btnstyle);
            change_mode->setStyleSheet(night_btnstyle);
        }
}

MainWindow::~MainWindow()
{
}
