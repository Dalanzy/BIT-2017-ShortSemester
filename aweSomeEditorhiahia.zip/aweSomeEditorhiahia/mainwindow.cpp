#include "mainwindow.h"
#include <QFont>

//using namespace std;


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent)
{
    this->setupUi(this);
    configEditor = new CodeEditor();
    QFont font("Microsoft YaHei");
    configEditor->setFont(font);
    configEditor->setMode(EDIT);

    open = new QPushButton("OPEN FILE", this);
    QFont font1("Microsoft YaHei");
    open->setFont(font1);
    connect(open, SIGNAL(clicked()), this, SLOT(slotOpenFileDialog()));

    debug = new QPushButton("DEBUG", this);
    debug->setFont(font1);

    //2个Button和1个CodeEditor的布局
    //gridLayout->setSpacing(60);
    gridLayout->addWidget(open,0,0);
    gridLayout->addWidget(debug,0,1);
    gridLayout->setSpacing(10);
    gridLayout->addWidget(configEditor,1,0,1,2);
    //QTextDocument temp = configEditor->document();
    MyHighLighter *highlighter = new MyHighLighter(configEditor->document());

    //---窗口属性
    resize(400, 300);
    setWindowTitle("min-C解释器");
}

MainWindow::~MainWindow()
{
}
